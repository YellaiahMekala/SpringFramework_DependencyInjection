package com.explore.sbScheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}

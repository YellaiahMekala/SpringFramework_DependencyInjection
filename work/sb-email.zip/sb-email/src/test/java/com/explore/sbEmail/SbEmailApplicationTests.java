package com.explore.sbEmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
